(this["webpackJsonppancake-frontend"]=this["webpackJsonppancake-frontend"]||[]).push([[10],{921:function(n,p){}}]);
//# sourceMappingURL=10.83ffaa6e.chunk.js.map